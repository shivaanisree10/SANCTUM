"""
Accessible, high-contrast, readable grayscale stylesheet for SANCTUM GUI.
Complies with WCAG guidelines:
- Does not rely on color alone (uses borders, text labels, icons/tags).
- Clear focus indicators for full keyboard navigation (Tab/Shift+Tab, Enter, Space).
- Highly legible typography and spacing.
"""

ACCESSIBLE_STYLESHEET = """
QWidget {
    background-color: #F8F9FA;
    color: #1A1A1A;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 13px;
}

/* Clear keyboard focus indicator */
QWidget:focus {
    outline: 2px solid #000000;
}

QWizard {
    background-color: #FFFFFF;
}

QLabel {
    color: #1A1A1A;
}

QLabel#titleLabel {
    font-size: 18px;
    font-weight: bold;
    color: #000000;
    margin-bottom: 8px;
}

QLabel#warningLabel {
    font-size: 14px;
    font-weight: bold;
    color: #000000;
    background-color: #F0F0F0;
    border: 2px solid #000000;
    padding: 8px;
}

QRadioButton, QCheckBox {
    spacing: 8px;
    font-size: 13px;
    padding: 4px;
}

QRadioButton::indicator, QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border: 2px solid #333333;
    background: #FFFFFF;
}

QRadioButton::indicator:checked {
    background-color: #000000;
}

QCheckBox::indicator:checked {
    background-color: #000000;
}

QPushButton {
    background-color: #E2E4E8;
    color: #000000;
    border: 2px solid #4B5563;
    border-radius: 4px;
    padding: 6px 14px;
    font-weight: 600;
    min-height: 24px;
}

QPushButton:hover {
    background-color: #D1D5DB;
}

QPushButton:pressed {
    background-color: #9CA3AF;
}

QPushButton:disabled {
    background-color: #F3F4F6;
    color: #9CA3AF;
    border-color: #D1D5DB;
}

QPushButton#destructiveButton {
    background-color: #333333;
    color: #FFFFFF;
    border: 2px solid #000000;
    font-weight: bold;
}

QPushButton#destructiveButton:hover {
    background-color: #000000;
}

QPushButton#destructiveButton:disabled {
    background-color: #E5E7EB;
    color: #9CA3AF;
    border-color: #D1D5DB;
}

QTableWidget {
    background-color: #FFFFFF;
    border: 1px solid #9CA3AF;
    gridline-color: #E5E7EB;
    selection-background-color: #374151;
    selection-color: #FFFFFF;
}

QHeaderView::section {
    background-color: #E5E7EB;
    color: #111827;
    font-weight: bold;
    padding: 6px;
    border: 1px solid #D1D5DB;
}

QProgressBar {
    border: 2px solid #374151;
    border-radius: 4px;
    text-align: center;
    font-weight: bold;
    color: #000000;
    background-color: #E5E7EB;
    height: 24px;
}

QProgressBar::chunk {
    background-color: #4B5563;
}

QLineEdit, QTextEdit {
    background-color: #FFFFFF;
    border: 2px solid #4B5563;
    border-radius: 4px;
    padding: 6px;
    color: #000000;
}

QLineEdit:focus, QTextEdit:focus {
    border: 2px solid #000000;
}
"""
