import os
from PyQt6.QtWidgets import (
    QWizard,
    QWizardPage,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QRadioButton,
    QButtonGroup,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QComboBox,
    QLineEdit,
    QCheckBox,
    QPushButton,
    QProgressBar,
    QTextEdit,
    QMessageBox,
)
from PyQt6.QtCore import Qt, QTimer

from sanctum.gui.styles import ACCESSIBLE_STYLESHEET
from sanctum.gui.worker import ExecutionWorker, ProgressUpdate
from sanctum.safety.guard import SafetyGuard
from sanctum.safety.models import OperationMode


class ModeSelectionPage(QWizardPage):
    """Page 1: Launch / Mode Selection (Locked for entire session)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Stage 1 of 6: Operation Mode Selection")
        self.setSubTitle("Select the operational branch for this session. Mode locks once confirmed.")

        layout = QVBoxLayout(self)

        info = QLabel(
            "Security Invariant: The chosen operational branch is locked for the entire session.\n"
            "Destructive sanitization and forensic recovery maintain separate safety boundaries."
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        layout.addSpacing(10)

        self.btn_group = QButtonGroup(self)

        self.radio_sanitize = QRadioButton("DESTRUCTIVE SANITIZATION (Data Overwrite & Firmware Purge)")
        self.radio_sanitize.setObjectName("destructiveRadio")
        self.radio_sanitize.setChecked(True)
        self.btn_group.addButton(self.radio_sanitize)
        layout.addWidget(self.radio_sanitize)

        self.radio_acquire = QRadioButton("FORENSIC ACQUISITION (Write-Blocked Bit-Stream Imaging)")
        self.btn_group.addButton(self.radio_acquire)
        layout.addWidget(self.radio_acquire)

        self.radio_recovery = QRadioButton("FORENSIC RECOVERY & CARVING (Deleted Reconstruction & Carving)")
        self.btn_group.addButton(self.radio_recovery)
        layout.addWidget(self.radio_recovery)

        layout.addStretch()

    def get_selected_mode(self) -> str:
        if self.radio_sanitize.isChecked():
            return "SANITIZATION"
        elif self.radio_acquire.isChecked():
            return "ACQUISITION"
        else:
            return "RECOVERY"


class DeviceInventoryPage(QWizardPage):
    """Page 2: Device Inventory (Boot disks visibly protected, serials/capacity clearly displayed)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Stage 2 of 6: Storage Device Inventory")
        self.setSubTitle("Select target device. System/boot disks are visibly protected.")

        layout = QVBoxLayout(self)

        self.table = QTableWidget(self)
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            "Device Path", "Serial Number", "Capacity (GB)", "Type", "Status", "Protection Flag"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.itemSelectionChanged.connect(self._on_selection_changed)
        layout.addWidget(self.table)

        self.status_label = QLabel("Select a non-protected storage drive to proceed.")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.selected_device = None
        self._populate_inventory()

    def _populate_inventory(self):
        devices = [
            {
                "path": "\\\\.\\PhysicalDrive0",
                "serial": "NVME-SYS-BOOT-0012",
                "capacity": 512.0,
                "type": "NVMe",
                "status": "ONLINE (System Boot)",
                "protected": True,
            },
            {
                "path": "\\\\.\\PhysicalDrive1",
                "serial": "WD-WCC4N5PA891",
                "capacity": 931.5,
                "type": "SATA HDD",
                "status": "ONLINE",
                "protected": False,
            },
            {
                "path": "virtual://test_media",
                "serial": "VIRT-TEST-001",
                "capacity": 0.1,
                "type": "Virtual DAL",
                "status": "ONLINE",
                "protected": False,
            },
        ]

        self.table.setRowCount(len(devices))
        for row, d in enumerate(devices):
            p_item = QTableWidgetItem(d["path"])
            s_item = QTableWidgetItem(d["serial"])
            c_item = QTableWidgetItem(f"{d['capacity']:.1f} GB")
            t_item = QTableWidgetItem(d["type"])
            st_item = QTableWidgetItem(d["status"])
            prot_item = QTableWidgetItem("[PROTECTED SYSTEM DISK]" if d["protected"] else "[AVAILABLE TARGET]")

            if d["protected"]:
                # High-contrast label tag indicating protected disk
                p_item.setFlags(p_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
                s_item.setFlags(s_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
                c_item.setFlags(c_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
                t_item.setFlags(t_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
                st_item.setFlags(st_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)
                prot_item.setFlags(prot_item.flags() & ~Qt.ItemFlag.ItemIsEnabled)

            self.table.setItem(row, 0, p_item)
            self.table.setItem(row, 1, s_item)
            self.table.setItem(row, 2, c_item)
            self.table.setItem(row, 3, t_item)
            self.table.setItem(row, 4, st_item)
            self.table.setItem(row, 5, prot_item)

    def _on_selection_changed(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            self.selected_device = None
            self.status_label.setText("Select a non-protected storage drive to proceed.")
            self.completeChanged.emit()
            return

        row = selected_rows[0].row()
        serial = self.table.item(row, 1).text()
        prot_text = self.table.item(row, 5).text()

        if "PROTECTED" in prot_text:
            self.selected_device = None
            self.status_label.setText("REFUSAL: System/boot drive is strictly protected against execution.")
        else:
            self.selected_device = {
                "path": self.table.item(row, 0).text(),
                "serial": serial,
                "capacity_str": self.table.item(row, 2).text(),
                "capacity_bytes": 104857600 if "virt" in serial.lower() else int(931.5 * 1024 * 1024 * 1024),
            }
            self.status_label.setText(f"Selected Target: {self.selected_device['path']} (Serial: {serial})")

        self.completeChanged.emit()

    def isComplete(self) -> bool:
        return self.selected_device is not None


class MethodPlanPage(QWizardPage):
    """Page 3: Method / Acquisition Plan."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Stage 3 of 6: Operation Specification & Policy")
        self.setSubTitle("Configure the sanitization algorithm or forensic acquisition parameters.")

        layout = QVBoxLayout(self)

        self.mode_label = QLabel()
        self.mode_label.setObjectName("titleLabel")
        layout.addWidget(self.mode_label)

        self.policy_combo = QComboBox(self)
        layout.addWidget(QLabel("Select Method / Standard:"))
        layout.addWidget(self.policy_combo)

        layout.addSpacing(10)
        self.details_label = QLabel()
        self.details_label.setWordWrap(True)
        layout.addWidget(self.details_label)

        layout.addStretch()

    def initializePage(self):
        wizard = self.wizard()
        mode = wizard.mode
        self.policy_combo.clear()

        if mode == "SANITIZATION":
            self.mode_label.setText("DESTRUCTIVE SANITIZATION POLICY")
            self.policy_combo.addItems([
                "NIST-Clear (Single Zero Pass)",
                "NIST-Clear-Random (Single Pseudo-Random Pass)",
                "DoD-3pass (DoD 5220.22-M 3-Pass Overwrite)",
            ])
            self.details_label.setText(
                "NOTICE: Destructive operation will permanently overwrite all sectors, partition tables, and file systems."
            )
        elif mode == "ACQUISITION":
            self.mode_label.setText("FORENSIC ACQUISITION PARAMETERS")
            self.policy_combo.addItems([
                "RAW / DD Bit-Stream Image",
                "Expert Witness E01 (Compressed)",
                "Advanced Forensic Format 4 (AFF4)",
            ])
            self.details_label.setText(
                "Source drive will be read-only write-blocked. Exact SHA-256 integrity digest will be recorded."
            )
        else:
            self.mode_label.setText("RECOVERY & TIMELINE PLAN")
            self.policy_combo.addItems([
                "Deleted File Recovery with Parent Tracking",
                "Aho-Corasick Carving & Signature Scanning",
                "Unified Chronological Forensic Timeline",
            ])
            self.details_label.setText("Virtual read-only parsing of file-system metadata and unallocated sectors.")


class ConfirmationPage(QWizardPage):
    """
    Page 4: Confirmation.
    Strict Safety Invariants:
    - Destructive operations clearly labelled DESTRUCTIVE.
    - Confirmation requires manually entering the serial tail (last 4 characters).
    - Destructive button/progression must NOT be immediately active.
    - No accidental single-click execution.
    - 3-second safety unlock timer before the button becomes enabled.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Stage 4 of 6: Cryptographic Confirmation & Safety Gate")
        self.setSubTitle("Confirm intention to proceed. Destructive actions require deliberate operator verification.")

        self.layout = QVBoxLayout(self)

        self.destruct_banner = QLabel("ATTENTION: YOU ARE PREPARING A DESTRUCTIVE SANITIZATION OPERATION")
        self.destruct_banner.setObjectName("warningLabel")
        self.layout.addWidget(self.destruct_banner)

        self.summary_label = QLabel()
        self.summary_label.setWordWrap(True)
        self.layout.addWidget(self.summary_label)

        self.layout.addSpacing(10)
        self.instruction_label = QLabel()
        self.instruction_label.setWordWrap(True)
        self.layout.addWidget(self.instruction_label)

        self.serial_tail_input = QLineEdit(self)
        self.serial_tail_input.setPlaceholderText("Enter required serial confirmation characters")
        self.serial_tail_input.textChanged.connect(self._validate_input)
        self.layout.addWidget(self.serial_tail_input)

        self.acknowledgement_checkbox = QCheckBox(
            "I explicitly acknowledge that this action cannot be undone and media will be permanently altered.",
            self,
        )
        self.acknowledgement_checkbox.stateChanged.connect(self._validate_input)
        self.layout.addWidget(self.acknowledgement_checkbox)

        self.timer_label = QLabel("Safety lock: Waiting 3 seconds before allowing confirmation...")
        self.layout.addWidget(self.timer_label)

        self.timer_unlocked = False
        self.expected_tail = ""

    def initializePage(self):
        wizard = self.wizard()
        dev = wizard.device
        serial = dev["serial"] if dev else "UNKNOWN"
        self.expected_tail = serial[-4:] if len(serial) >= 4 else serial

        is_destructive = (wizard.mode == "SANITIZATION")
        if is_destructive:
            self.destruct_banner.setText("CRITICAL WARNING: [DESTRUCTIVE OPERATION]")
            self.destruct_banner.show()
            self.acknowledgement_checkbox.show()
            self.instruction_label.setText(
                f"SAFETY VERIFICATION: To prevent accidental erasure, type the last 4 characters of the target drive serial ({self.expected_tail}):"
            )
        else:
            self.destruct_banner.hide()
            self.acknowledgement_checkbox.hide()
            self.instruction_label.setText(
                f"Type the last 4 characters of the target device serial ({self.expected_tail}) to confirm forensic task initiation:"
            )

        self.summary_label.setText(
            f"Target Device: {dev.get('path', 'N/A')}\n"
            f"Hardware Serial: {serial}\n"
            f"Capacity: {dev.get('capacity_str', 'N/A')}\n"
            f"Mode: {wizard.mode}\n"
            f"Specification: {wizard.method_page.policy_combo.currentText()}"
        )

        self.serial_tail_input.clear()
        self.timer_unlocked = False
        self.timer_label.setText("Safety lock: Please review the plan (3s timer active)...")
        self.timer_label.show()

        # Start 3-second safety unlock timer
        QTimer.singleShot(3000, self._on_timer_unlocked)
        self.completeChanged.emit()

    def _on_timer_unlocked(self):
        self.timer_unlocked = True
        self.timer_label.setText("Safety lock unlocked. Please enter confirmation tail.")
        self._validate_input()

    def _validate_input(self):
        if not self.timer_unlocked:
            return

        typed_tail = self.serial_tail_input.text().strip()
        wizard = self.wizard()
        is_destructive = (wizard.mode == "SANITIZATION")

        tail_matches = (typed_tail.upper() == self.expected_tail.upper())
        ack_checked = self.acknowledgement_checkbox.isChecked() if is_destructive else True

        if tail_matches and ack_checked:
            self.timer_label.setText("Operator verification confirmed. You may now proceed.")
        else:
            self.timer_label.setText("Awaiting correct serial confirmation...")

        self.completeChanged.emit()

    def isComplete(self) -> bool:
        if not self.timer_unlocked:
            return False
        typed_tail = self.serial_tail_input.text().strip()
        wizard = self.wizard()
        is_destructive = (wizard.mode == "SANITIZATION")
        ack_checked = self.acknowledgement_checkbox.isChecked() if is_destructive else True
        return (typed_tail.upper() == self.expected_tail.upper()) and ack_checked


class ExecutionPage(QWizardPage):
    """
    Page 5: Execution.
    Runs long-running worker thread, keeping GUI fully responsive.
    Displays: Throughput, ETA, Pass, LBA, Errors, Status message.
    Abort button is always available.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Stage 5 of 6: Operation Execution")
        self.setSubTitle("Operation in progress. Background thread executing task.")

        layout = QVBoxLayout(self)

        self.status_label = QLabel("Initializing worker thread...")
        self.status_label.setObjectName("titleLabel")
        layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar(self)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        layout.addWidget(self.progress_bar)

        # Telemetry metrics grid
        self.metrics_label = QLabel(
            "Throughput: 0.0 MB/s | ETA: Calculating... | Pass: 1/1 | Current LBA: 0 | Errors: 0"
        )
        self.metrics_label.setWordWrap(True)
        layout.addWidget(self.metrics_label)

        self.log_text = QTextEdit(self)
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)

        # Abort Button
        btn_layout = QHBoxLayout()
        self.abort_btn = QPushButton("ABORT OPERATION", self)
        self.abort_btn.setObjectName("destructiveButton")
        self.abort_btn.clicked.connect(self._on_abort_clicked)
        btn_layout.addStretch()
        btn_layout.addWidget(self.abort_btn)
        layout.addLayout(btn_layout)

        self.worker = None
        self.is_done = False
        self.execution_results = None

    def initializePage(self):
        wizard = self.wizard()
        self.is_done = False
        self.progress_bar.setValue(0)
        self.log_text.clear()
        self.abort_btn.setEnabled(True)

        dev = wizard.device
        serial = dev["serial"] if dev else "VIRT-TEST-001"
        capacity = dev.get("capacity_bytes", 104857600) if dev else 104857600
        policy_or_format = wizard.method_page.policy_combo.currentText()

        self.log_text.append(f"Starting {wizard.mode} on {serial}...")

        # Spawn background worker thread
        self.worker = ExecutionWorker(
            mode=wizard.mode,
            device_serial=serial,
            device_capacity=capacity,
            policy_or_format=policy_or_format,
            operator="Operator Mulder",
            parent=self,
        )
        self.worker.progress_changed.connect(self._on_progress_update)
        self.worker.finished_success.connect(self._on_success)
        self.worker.finished_aborted.connect(self._on_aborted)
        self.worker.finished_error.connect(self._on_error)
        self.worker.start()
        self.completeChanged.emit()

    def _on_progress_update(self, update: ProgressUpdate):
        self.progress_bar.setValue(int(update.percent))
        self.status_label.setText(f"{update.status_message} ({update.percent:.1f}%)")
        self.metrics_label.setText(
            f"Throughput: {update.throughput_mbps} MB/s | "
            f"ETA: {update.eta_seconds}s | "
            f"Pass: {update.current_pass}/{update.total_passes} | "
            f"LBA: {update.current_lba}/{update.total_lba} | "
            f"Errors: {update.error_count}"
        )

    def _on_success(self, result_dict: dict):
        self.is_done = True
        self.abort_btn.setEnabled(False)
        self.execution_results = result_dict
        self.status_label.setText("Execution successfully completed.")
        self.progress_bar.setValue(100)
        for line in result_dict.get("audit_log", []):
            self.log_text.append(line)
        self.completeChanged.emit()

    def _on_aborted(self):
        self.is_done = False
        self.abort_btn.setEnabled(False)
        self.status_label.setText("OPERATION ABORTED BY OPERATOR.")
        self.log_text.append("[ALERT] Safe abort sequence finished. No further sectors modified.")

    def _on_error(self, err_msg: str):
        self.is_done = False
        self.abort_btn.setEnabled(False)
        self.status_label.setText(f"ERROR: {err_msg}")
        self.log_text.append(f"[ERROR] {err_msg}")

    def _on_abort_clicked(self):
        if self.worker and self.worker.isRunning():
            confirm = QMessageBox.question(
                self,
                "Confirm Abort",
                "Are you sure you wish to immediately abort the ongoing operation?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if confirm == QMessageBox.StandardButton.Yes:
                self.abort_btn.setEnabled(False)
                self.status_label.setText("Aborting worker thread...")
                self.worker.abort()

    def isComplete(self) -> bool:
        return self.is_done


class ResultsPage(QWizardPage):
    """
    Page 6: Results.
    Displays: Verification verdict, Cryptographic hashes, Certificate/Report details, Audit log excerpt.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setTitle("Stage 6 of 6: Operation Verdict & Evidentiary Manifest")
        self.setSubTitle("Review final verification verdict, cryptographic digests, and audit trail.")

        layout = QVBoxLayout(self)

        self.verdict_label = QLabel()
        self.verdict_label.setObjectName("titleLabel")
        layout.addWidget(self.verdict_label)

        self.details_label = QLabel()
        self.details_label.setWordWrap(True)
        layout.addWidget(self.details_label)

        layout.addSpacing(10)
        layout.addWidget(QLabel("Audit Log Excerpt (Chained Cryptographic Provenance):"))
        self.audit_box = QTextEdit(self)
        self.audit_box.setReadOnly(True)
        layout.addWidget(self.audit_box)

    def initializePage(self):
        wizard = self.wizard()
        res = wizard.execution_page.execution_results or {}

        verdict = res.get("verification_result", "PASS")
        self.verdict_label.setText(f"FINAL VERDICT: {verdict}")

        hash_val = res.get("hash", "0" * 64)
        cert_id = res.get("certificate_id", "CERT-N/A")
        audit_dig = res.get("audit_digest", "N/A")

        self.details_label.setText(
            f"Operation Mode: {res.get('mode', 'N/A')}\n"
            f"Device Serial: {res.get('serial', 'N/A')}\n"
            f"Applied Policy / Format: {res.get('policy', 'N/A')}\n"
            f"SHA-256 Digest: {hash_val}\n"
            f"Generated Certificate: {cert_id}\n"
            f"Audit Trail Digest: {audit_dig}\n"
            f"Hardware Errors: {res.get('errors', 0)}"
        )

        self.audit_box.clear()
        for log_entry in res.get("audit_log", []):
            self.audit_box.append(log_entry)


class SanctumWizard(QWizard):
    """
    6-Stage Guided Forensic & Sanitization Wizard:
    1. Launch / Mode Selection
    2. Device Inventory
    3. Method / Acquisition Plan
    4. Confirmation (Serial tail, safety timer, deliberate acknowledgement)
    5. Execution (Worker thread, responsive GUI, live metrics, abortable)
    6. Results (Verdicts, hashes, certificate, audit excerpt)
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("SANCTUM Platform — Forensic Recovery & Sanitization Wizard")
        self.setStyleSheet(ACCESSIBLE_STYLESHEET)
        self.setMinimumSize(850, 600)

        # Pages
        self.mode_page = ModeSelectionPage(self)
        self.inventory_page = DeviceInventoryPage(self)
        self.method_page = MethodPlanPage(self)
        self.confirmation_page = ConfirmationPage(self)
        self.execution_page = ExecutionPage(self)
        self.results_page = ResultsPage(self)

        self.addPage(self.mode_page)
        self.addPage(self.inventory_page)
        self.addPage(self.method_page)
        self.addPage(self.confirmation_page)
        self.addPage(self.execution_page)
        self.addPage(self.results_page)

        # Mode locking for session
        self._mode_locked = False
        self._locked_mode = "SANITIZATION"

        # Wizard button setup
        self.setOption(QWizard.WizardOption.NoBackButtonOnStartPage, True)

    @property
    def mode(self) -> str:
        if not self._mode_locked:
            self._locked_mode = self.mode_page.get_selected_mode()
            self._mode_locked = True
        return self._locked_mode

    @property
    def device(self) -> dict:
        return self.inventory_page.selected_device
